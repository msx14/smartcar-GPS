#include "headfile.h"
#include "GlobalVar.h"
#include "BasicFun.h"
#include "FindLine.h"
#include "FillSpecialLine.h"
#include "MainProcess.h"
#include "CircleIsland.h"
#include "FirstLineProcess.h"
#include "canny.h"

//================================================================//
//  @brief  :		���в��ú���
//  @param  :		void
//  @return :		void
//  @note   :		void
//================================================================//
void SelectFirstLine(void)
{
	//GetFirstLineEage();
	FirstLineV4();
	//FindFirstEage_3();
	//if (!FindFirstEageV3())
	//	return;
}
//================================================================//
//  @brief  :		��ͨ��ͼ������
//  @param  :		void
//  @return :		void
//  @note   :		void
//================================================================//
void MainFill(void)
{
	VarInit();
	SelectFirstLine();
	g_RoadType = FirstRowProcess();
	//g_RoadType = FirstJudge();
	if (0 == g_RoadType)
	{
		FindLineNormal(1);
#if CIRCLE == 1
		if (RightPnt.Type == 2 && RightPnt.ErrRow - LeftPnt.ErrRow >= CIRCLEUP_TH && LeftPnt.ErrRow <= UP_EAGE + 20
			&& RightPnt.ErrCol < RIGHT_EAGE - 25)	//�һ����ж�
		{
			CircleFlag = IsCircleIsland(CR);
			if (CircleFlag)		//�ǻ��� ������ͼ
			{
				CircleState = 1;
				GetPointA();
				GetPointB();
				GetPointC();
				GetPointD();
				FillLineAB();
				FillLineCD();
				FillAllEage();
			}
			else;
		}
		else if (LeftPnt.Type == 2 && LeftPnt.ErrRow - RightPnt.ErrRow >= CIRCLEUP_TH && RightPnt.ErrRow <= UP_EAGE + 20
			&& LeftPnt.ErrCol > LEFT_EAGE + 25)	//�󻷵��ж�
		{
			CircleFlag = IsCircleIsland(CL);
			if (CircleFlag)		//�ǻ��� ������ͼ
			{
				CircleState = 1;
				GetPointA();
				GetPointB();
				GetPointC();
				GetPointD();
				FillLineAB();
				FillLineCD();
				FillAllEage();
			}
			else;
		}
		else
#elif CIRCLE == 2
		if (LeftPnt.Type == 2 && LeftPnt.ErrRow > UP_EAGE + 20 && RightPnt.ErrRow < UP_EAGE + 10
			&& LeftPnt.ErrCol < MIDDLE && RightPnt.ErrCol > MIDDLE - 7)
		{
			CircleFlag = IsCircleIsland(CL);
			if (CircleFlag)
			{
				CircleState = 1;
				GetPointA();
				GetPointB();
				GetPointC();
				GetPointD();
				FillLineAB();
				FillLineCD();
				FillAllEage();
			}
		}
		else if (RightPnt.Type == 2 && RightPnt.ErrRow > UP_EAGE + 20 & LeftPnt.ErrRow < UP_EAGE + 10
			& RightPnt.ErrCol > MIDDLE && LeftPnt.ErrCol < MIDDLE + 7)
		{
			CircleFlag = IsCircleIsland(CR);
			if (CircleFlag)
			{
				CircleState = 1;
				GetPointA();
				GetPointB();
				GetPointC();
				GetPointD();
				FillLineAB();
				FillLineCD();
				FillAllEage();
			}
		}
#endif // CIRCLE
			if (LeftPnt.Type == 2 && RightPnt.Type == 2)
			{
				if (LeftPnt.ErrRow - RightPnt.ErrRow > 10 || RightPnt.ErrRow - LeftPnt.ErrRow > 10)
				{
					FillBevelCross();
				}
				else
				{
					FillLevelCross();
				}
				FindLineNormal(0);
			}
#if BROKEN
			else if (LeftPnt.Type + RightPnt.Type == 3 && !BrokenFlag)
			{
				if (LeftPnt.ErrRow > 35 && RightPnt.ErrRow > 35)
				{
					Point pa = { LeftPnt.ErrRow, LeftPnt.ErrCol };
					Point pb = { RightPnt.ErrRow, RightPnt.ErrCol };
					BrokenFlag = JudgeInBroken_V2(pa, pb);
					//if (BrokenFlag) gpio_init(D1, GPO, 0);
				}
			}
#endif // BROKEN
		//#if BLOCK_OPEN
		//                if (BlockFlag_1)
		//                {
		//                        if (4 == LeftPnt.Type && 4 == RightPnt.Type)
		//                                 BlockFlag_1 = 0;
		//                        else 
		//                                 BlockFlag_2 = 1;
		//                }
		//                        
		//#endif //BLOCK_OPEN
	}
	if (1 == g_RoadType)
	{
		FindLineLost();
#if CIRCLE == 2
		if (LL[DOWN_EAGE] == LEFT_EAGE && RightPnt.ErrRow < UP_EAGE + 10
			&& RightPnt.ErrCol > MIDDLE)
		{
			CircleFlag = CL;
			CircleState = 2;
			GetPointA();
			GetPointB();
			GetPointC();
			GetPointD();
			FillLineAB();
			FillLineCD();
			FillAllEage();
		}
		else if (RL[DOWN_EAGE] == RIGHT_EAGE && LeftPnt.ErrRow < UP_EAGE + 10
			& LeftPnt.ErrCol < MIDDLE)
		{
			CircleFlag = CR;
			CircleState = 2;
			GetPointA();
			GetPointB();
			GetPointC();
			GetPointD();
			FillLineAB();
			FillLineCD();
			FillAllEage();
		}
		else
#endif
		if (1 == g_RoadType && 2 == LeftPnt.Type && 2 == RightPnt.Type)
		{
			FillBevelCross();
			FindLineNormal(0);
		}
	}
	if (2 == g_RoadType)
	{
		FillFourCross();
		FindLineNormal(0);
	}
	FillMiddleLine();
}


//================================================================//
//  @brief  :		��ͼ������
//  @param  :		void
//  @return :		void
//  @note   :		void
//================================================================//
void GetML(void)
{
#if BROKEN
	if (BrokenFlag == 2)
		BrokenFlag = JudgeOutBroken();
	if (BrokenFlag == 1)
		if (JudgeOutBroken())
		{
			BrokenFlag = 2;
		}
	if (BrokenFlag == 2)
		;
	else
#endif // BROKEN
	{
		CannyEage();
#if CIRCLE
		if (CircleFlag)		//is CircleIsland 
		{
			CircleFill();
		}
		else
#endif // CIRCLE
			MainFill();
	}
	//����У��
	if (RL[DOWN_EAGE] - LL[DOWN_EAGE] <= 40 || ML_Count > DOWN_EAGE - 20		//�±߽��С����Ч��������
		|| RightPnt.ErrCol - LeftPnt.ErrCol > 100)									//�ϱ߽粻����
	{
		ErrorFlag = 4;
	}
}

//================================================================//
//  @brief  :		�жϳ���·
//  @param  :		void
//  @return :		1 �����ڶ�·  0�Ѿ����˶�·
//  @note   :		void
//================================================================//
int JudgeOutBroken(void)
{
	CannyEage();
	VarInit();
	LeftPnt.Type = RightPnt.Type = 0;
	SelectFirstLine();
	static int Num_i = 0;
	static long int Sum = 0;
	static int BrokenAve[5] = { 0 };
	if (BrokenFlag == 1)
	{
		/*if (!Num_i)
		{
			if (Sum / Num_i - 30 > LightThreshold)
			{
				Sum = 0;
				Num_i = 0;
				return 1;
			}
		}
		Num_i++;
		Sum += LightThreshold;
		return 0;*/
		if (Num_i < 5)
		{
			if (Num_i > 0 && BrokenAve[Num_i - 1] - LightThreshold > 30)
				return 1;
			BrokenAve[Num_i++] = LightThreshold;
		}
		else
		{
			for (int i = 0; i < 4; i++)		//��������Ԫ��
				BrokenAve[i] = BrokenAve[i + 1];
			BrokenAve[4] = LightThreshold;
			//�ж�����
			for (int i = 0; i < 4; i++)
			{
				for (int j = i; j < 5; j++)
				{
					if (BrokenAve[i] - BrokenAve[j] > 30)
						return 1;
				}
			}
			return 0;
		}

		//		if (BrokenLastAve == 0)
		//		{
		//			BrokenLastAve = LightThreshold;
		//			return 0;
		//		}
		//		else
		//		{
		//			if (BrokenLastAve - LightThreshold > 30)
		//			{
		//                          BrokenLastAve = LightThreshold;
		//				return 1;
		//			}
		//			else 
		//                        {
		//                          BrokenLastAve = LightThreshold;
		//                          return 0;
		//                        }
		//		}
	}
	else
	{
		FindLineNormal(0);
		if (LeftPnt.ErrRow < DOWN_EAGE - 20 && RightPnt.ErrRow < DOWN_EAGE - 20)
		{
			if (RL[DOWN_EAGE] - LL[DOWN_EAGE] > 94 && RL[DOWN_EAGE - 1] - LL[DOWN_EAGE - 1] > 94
				&& RL[DOWN_EAGE - 2] - LL[DOWN_EAGE - 2] > 94 && RL[DOWN_EAGE - 3] - LL[DOWN_EAGE - 3] > 94)
			{
				BrokenLastAve = 0;
				return 0;
			}
			else return 2;
		}
		else
		{
			return 2;
		}
	}
}