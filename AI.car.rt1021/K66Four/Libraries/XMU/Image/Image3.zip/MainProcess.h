#ifndef MainProcess_H
#define MainProcess_H
void MainFill(void);
void GetML(void);
int StopCar(void);
void SelectFirstLine(void);
int JudgeOutBroken(void);
void DistBroken(void);
int IsStopLine(int line, int left, int right);
int DistStopLine(int* dist);
#endif // !MainProcess_H
#pragma once
