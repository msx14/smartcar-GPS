#include "GlobalVar.h"
#include "BasicFun.h"
#include "FindLine.h"
#include "FillSpecialLine.h"
#include "MainProcess.h"
#include "CircleIsland.h"
#include "FirstLineProcess.h"
#include "canny.h"
#include "SpecialElem.h"

//================================================================//
//  @brief  :		���в��ú���
//  @param  :		void
//  @return :		void
//  @note   :		void
//================================================================//
void SelectFirstLine(void)
{
	//GetFirstLineEage();
	FirstLineV4();
	//FindFirstEage_3();
	//if (!FindFirstEageV3())
	//	return;
}
//================================================================//
//  @brief  :		��ͨ��ͼ������
//  @param  :		void
//  @return :		void
//  @note   :		void
//================================================================//
void MainFill(void)
{
	VarInit();
	SelectFirstLine();
	g_RoadType = FirstRowProcess();
	if (0 == g_RoadType)
	{
		FindLineNormal(1);
#if RAMP
		//ʶ���µ�
		if (!RampFlag && !BlockFlag && !BrokenFlag && !CircleFlag
			&& LeftPnt.ErrRow <= UP_EAGE + 1 && RightPnt.ErrRow <= UP_EAGE + 1)
		{
			RampFlag = IsRamp();
		}
#endif
#if CIRCLE == 1
		if (RightPnt.Type == 2 && RightPnt.ErrRow - LeftPnt.ErrRow >= CIRCLEUP_TH && LeftPnt.ErrRow <= UP_EAGE + 20
			&& RightPnt.ErrCol < RIGHT_EAGE - 25)	//�һ����ж�
		{
			CircleFlag = IsCircleIsland(CR);
			string.Format("\r\n CircleFlag = %d \r\n", CircleFlag); PrintDebug(string);
			if (CircleFlag)		//�ǻ��� ������ͼ
			{
				CircleState = 1;
				GetPointA();
				GetPointB();
				GetPointC();
				GetPointD();
				FillLineAB();
				FillLineCD();
				FillAllEage();
			}
			else;
		}
		else if (LeftPnt.Type == 2 && LeftPnt.ErrRow - RightPnt.ErrRow >= CIRCLEUP_TH && RightPnt.ErrRow <= UP_EAGE + 20
			&& LeftPnt.ErrCol > LEFT_EAGE + 25)	//�󻷵��ж�
		{
			CircleFlag = IsCircleIsland(CL);
			string.Format("\r\n CircleFlag = %d \r\n", CircleFlag); PrintDebug(string);
			if (CircleFlag)		//�ǻ��� ������ͼ
			{
				CircleState = 1;
				GetPointA();
				GetPointB();
				GetPointC();
				GetPointD();
				FillLineAB();
				FillLineCD();
				FillAllEage();
			}
			else;
}
		else
#elif CIRCLE == 2
		if (LeftPnt.Type == 2 && LeftPnt.ErrRow > UP_EAGE + 20 && RightPnt.ErrRow < UP_EAGE + 10
			&& LeftPnt.ErrCol < MIDDLE && RightPnt.ErrCol > MIDDLE - 7 && IsCircleIsland(CL))
		{
			//CircleFlag = CL;
			CircleState = 1;
			GetPointA();
			GetPointB();
			GetPointC();
			GetPointD();
			FillLineAB();
			FillLineCD();
			FillAllEage();
		}
		else if (RightPnt.Type == 2 && RightPnt.ErrRow > UP_EAGE + 20 && LeftPnt.ErrRow < UP_EAGE + 10
			&& RightPnt.ErrCol > MIDDLE && LeftPnt.ErrCol < MIDDLE + 7 && IsCircleIsland(CR))
		{
			//CircleFlag = CR;
			CircleState = 1;
			GetPointA();
			GetPointB();
			GetPointC();
			GetPointD();
			FillLineAB();
			FillLineCD();
			FillAllEage();
		}
		else
#endif // CIRCLE
			if (LeftPnt.Type == 2 && RightPnt.Type == 2)		//ʮ�ֲ�ͼ
			{
				if (LeftPnt.ErrRow - RightPnt.ErrRow > 10 || RightPnt.ErrRow - LeftPnt.ErrRow > 10)
				{
					FillBevelCross();
				}
				else
				{
					FillLevelCross();
				}
				FindLineNormal(0);

			}
#if BROKEN
			else if (LeftPnt.Type + RightPnt.Type == 3 && !BrokenFlag)
			{
				if (LeftPnt.ErrRow > 35 && RightPnt.ErrRow > 35)
				{
					Point pa = { LeftPnt.ErrRow, LeftPnt.ErrCol };
					Point pb = { RightPnt.ErrRow, RightPnt.ErrCol };
					//BrokenFlag = JudgeInBroken(pa, pb);
					BrokenFlag = JudgeInBroken_V2(pa, pb);

				}
			}
#endif // BROKEN
		////ʶ��ͣ��
		//if (LeftPnt.ErrRow <= UP_EAGE + 20 && RightPnt.ErrRow <= UP_EAGE + 20
		//	&& !StopLineFlag && DistStopLine(&StopLineDist))
		//	StopLineFlag = 1;
#if BLOCK_BROKEN
		//ʶ������Ԫ��
		if (!BlockFlag && 2 != BrokenFlag && !RampFlag && !CircleFlag)		//��··���ж�
		{
			int flag = JudgeSpecialElem(LeftIntLine, RightIntLine);
			if (1 == flag)
			{
				BlockFlag = 1;
			}
			else if (2 == flag)
			{
				BrokenFlag = 1;
			}
			else;
		}
#endif
	}
	if (1 == g_RoadType)
	{
		FindLineLost();
#if CIRCLE == 2
		if (LL[DOWN_EAGE] == LEFT_EAGE && RightPnt.ErrRow < UP_EAGE + 10

			&& RightPnt.ErrCol > MIDDLE)
		{
			CircleFlag = CL;
			CircleState = 2;
			GetPointA();
			GetPointB();
			GetPointC();
			GetPointD();
			FillLineAB();
			FillLineCD();
			FillAllEage();
		}
		else if (RL[DOWN_EAGE] == RIGHT_EAGE && LeftPnt.ErrRow < UP_EAGE + 10
			&& LeftPnt.ErrCol < MIDDLE)
		{
			CircleFlag = CR;
			CircleState = 2;
			GetPointA();
			GetPointB();
			GetPointC();
			GetPointD();
			FillLineAB();
			FillLineCD();
			FillAllEage();
		}
		else
#endif
			if (1 == g_RoadType && 2 == LeftPnt.Type && 2 == RightPnt.Type)
			{
				FillBevelCross();
				FindLineNormal(0);
			}
	}
	if (2 == g_RoadType)
	{
		FillFourCross();
		FindLineNormal(0);
	}
	FillMiddleLine();
}


//================================================================//
//  @brief  :		��ͼ������
//  @param  :		void
//  @return :		void
//  @note   :		void
//================================================================//
void GetML(void)
{
#if BROKEN
	if (BrokenFlag == 2)
		BrokenFlag = JudgeOutBroken();
	if (BrokenFlag == 1)
		if (JudgeOutBroken())
		{
			BrokenFlag = 2;
		}
	if (BrokenFlag == 2)
		;
	else
#endif // BROKEN
	{
		CannyEage();
#if CIRCLE
		if (CircleFlag)		//is CircleIsland 
		{
			CircleFill();
		}
		else
#endif // CIRCLE
			MainFill();
	}
	//����У��
	if (RL[DOWN_EAGE] - LL[DOWN_EAGE] <= 40 || ML_Count > DOWN_EAGE - 20		//�±߽��С����Ч��������
		|| RightPnt.ErrCol - LeftPnt.ErrCol > 100)									//�ϱ߽粻����
	{
		ErrorFlag = 4;
	}
}

