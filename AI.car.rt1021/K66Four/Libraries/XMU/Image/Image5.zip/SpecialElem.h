#ifndef SPECIALELEM_H
#define SPECIALELEM_H
void SpecialElemFill(void);
int JudgeSpecialElem(int left_line, int right_line);
int JudgeSpecialLine(int left_line, int right_line);
int IsBrokenBlock(int left_line, int right_line);
int IsRamp(void);
int JudgeOutBroken(void);
int IsStopLine(int line, int left, int right);
int DistStopLine(int);
int JudgeInBroken(Point pa, Point pb);
int JudgeInBroken_V2(Point pa, Point pb);
int IsConnectPoint(Point pa, Point pb);
#endif // !SPECIALELEM_H
#pragma once
