#ifndef CANNY_H
#define CANNY_H
void CannyEage(void);
int GetAveGray(int row);
#endif // !CANNY_H
