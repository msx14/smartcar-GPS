#ifndef MainProcess_H
#define MainProcess_H
void MainFill(void);
void GetML(void);
void SelectFirstLine(void);

#endif // !MainProcess_H
#pragma once
