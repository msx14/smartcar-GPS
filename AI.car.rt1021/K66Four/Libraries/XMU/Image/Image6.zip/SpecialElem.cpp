#include "GlobalVar.h"
#include "BasicFun.h"
#include "FindLine.h"
#include "FillSpecialLine.h"
#include "MainProcess.h"
#include "CircleIsland.h"
#include "FirstLineProcess.h"
#include "canny.h"
#include "SpecialElem.h"


//================================================================//
//  @brief  :		����Ԫ��
//  @param  :		�µ� ·�� ��· ͣ����
//  @return :		void
//  @note   :		�µ�����ͼ�� ѭ����������־
//					·�ϣ���ͼ�� ��ͼ��������������־һ��
//					��·����ͼ�� ��·��ͼģʽ
//					ͣ���ߣ���ͼ�� ѭ����������־
//================================================================//
void SpecialElemFill(void)
{
	VarInit();
	LeftPnt.Type = RightPnt.Type = 0;
	SelectFirstLine();
	FindLineNormal(0);
	if (1 == BrokenFlag)
	{
		if (LeftIntLine < UP_EAGE + 15 && RightIntLine < UP_EAGE + 15			//ͣ��
			&& LeftPnt.ErrRow < UP_EAGE + 15 && RightPnt.ErrRow < UP_EAGE + 15
			&& DistStopLine(UP_EAGE + 15))
		{
			StopLineFlag = 1;
			BrokenFlag = 0;
		}
		else if (1 == JudgeOutBroken())
		{
			BrokenFlag = 2;			//��·
		}
		else if (1 == JudgeSpecialElem(LeftIntLine, RightIntLine))	
		{
			BlockFlag = 1;			//·��
			BrokenFlag = 0;
		}
		LeftPnt.ErrRow = MAX(LeftPnt.ErrRow, LeftIntLine);
		RightPnt.ErrRow = MAX(RightPnt.ErrRow, RightIntLine);
		FillMiddleLine();
	}
	else if (2 == BrokenFlag)
	{
		if (JudgeOutBroken())
		{
			BrokenFlag = 0;
			SpecialElemFlag = 0;
		}
	}
	else if (BlockFlag)
	{
		LeftPnt.ErrRow = MAX(LeftPnt.ErrRow, LeftIntLine);
		RightPnt.ErrRow = MAX(RightPnt.ErrRow, RightIntLine);
		FillMiddleLine();
	}
	else if (RampFlag)
	{
		LeftPnt.ErrRow = MAX(LeftPnt.ErrRow, LeftIntLine);
		RightPnt.ErrRow = MAX(RightPnt.ErrRow, RightIntLine);
		FillMiddleLine();
	}
	else if (StopLineFlag)
	{
		LeftPnt.ErrRow = MAX(LeftPnt.ErrRow, LeftIntLine);
		RightPnt.ErrRow = MAX(RightPnt.ErrRow, RightIntLine);
		FillMiddleLine();
	}
	else
	{
		SpecialElemFlag = 0;
	}
}


//================================================================//
//  @brief  :		·�϶�·�ж�
//  @param  :		void 
//  @return :		1·�� 2��·
//  @note   :		void
//================================================================//
int JudgeSpecialElem(int left_line, int right_line)
{
	if (JudgeSpecialLine(left_line, right_line))
	{
		if (IsBrokenBlock(left_line, right_line))
			return 1;
		else return 2;
	}
	else return 0;
}

//================================================================//
//  @brief  :		�������жϷ������
//  @param  :		�������� ��������
//  @return :		1 ȷ����
//  @note   :		ȫ�ֱ���LL RL
//================================================================//
int JudgeSpecialLine(int left_line, int right_line)
{
	const int StartLine = 33;		//�ж���ʼ����
	if (left_line < StartLine && right_line < StartLine
		|| left_line - right_line > 8 || right_line - left_line > 8
		|| LL[left_line] + 15 > RL[right_line])
		return 0;

	const int diff = 2;
	int NewRow = left_line;
	int NewRow2 = right_line;
	int OldRow = NewRow;
	int OldRow2 = NewRow2;
	int Middle = (LL[left_line] + RL[right_line]) >> 1;
	for (int i = LL[left_line] + 1; i <= Middle; i++)
	{
		NewRow = SearchUpEage(OldRow + 2, i);
		if (NewRow - OldRow > diff || OldRow - NewRow > diff)
			return 0;
		OldRow = NewRow;
	}
	for (int i = RL[right_line] - 1; i >= Middle; i--)
	{
		NewRow2 = SearchUpEage(OldRow2 + 2, i);
		if (NewRow2 - OldRow2 > diff || OldRow2 - NewRow2 > diff)
			return 0;
		OldRow2 = NewRow2;
	}
	if (NewRow == NewRow2)return 1;
	else return 0;
}

//================================================================//
//  @brief  :		�ж�·��
//  @param  :		left_line right_line
//  @return :		0��   1·��
//  @note   :		ȫ�ֱ��� LL RL
//================================================================//
int IsBrokenBlock(int left_line, int right_line)
{
	int left_end = 0, right_end = 0;
	int left_num = 0, right_num = 0;
	int left_flag = 0, right_flag = 0;
	int left_eage[70], right_eage[70];
	left_eage[left_line] = LL[left_line]; right_eage[right_line] = RL[right_line];
	for (int i = left_line - 1; i > UP_EAGE; i--)
	{
		left_eage[i] = GetLL(i, left_eage[i + 1]);
		if (left_eage[i] - left_eage[i + 1] > FINDLINE_TH)
			left_eage[i] = SearchLeftNoEage(i, left_eage[i]) + 3;
		else if (left_eage[i + 1] - left_eage[i] > FINDLINE_TH || left_eage[i] == LEFT_EAGE)
		{
			left_end = i + 1;
			break;
		}
	}
	if (left_end == 0) left_end = UP_EAGE + 1;
	for (int i = right_line - 1; i > UP_EAGE; i--)
	{
		right_eage[i] = GetRL(i, right_eage[i + 1]);
		if (right_eage[i + 1] - right_eage[i] > FINDLINE_TH)
			right_eage[i] = SearchRightNoEage(i, right_eage[i]) - 3;
		else if (right_eage[i] - right_eage[i + 1] > FINDLINE_TH || right_eage[i] == RIGHT_EAGE)
		{
			right_end = i + 1;
			break;
		}
	}
	if (right_end == 0) right_end = UP_EAGE + 1;

	if (left_line - left_end < 5)
		left_flag = 0;
	else left_flag = 1;
	if (right_line - right_end < 5)
		right_flag = 0;
	else right_flag = 1;

	if (left_flag || right_flag)
	{
		if (left_flag)
		{
			for (int i = left_line; i > left_end; i--)
			{
				if (left_eage[i + 1] - left_eage[i] >= 0)
					left_num++;
			}
			if (left_num >= (left_line - left_end) * 0.8)
				left_num = 1;
			else left_num = 0;
		}
		if (right_flag)
		{
			for (int i = right_line; i > right_end; i--)
			{
				if (right_eage[i] - right_eage[i + 1] >= 0)
					right_num++;
			}
			if (right_num >= (right_line - right_end) * 0.8)
				right_num = 1;
			else right_num = 0;
		}
		if (!(left_num ^ left_flag) && !(right_num ^ right_flag))
			return 1;
		else return 0;
	}
	else return 0;
}

//================================================================//
//  @brief  :		ʶ���µ�
//  @param  :		void
//  @return :		void
//  @note   :		void
//================================================================//
int IsRamp(void)
{
	const int DiffTh = 1000;
	int DiffSum = 0;
	for (int i = DOWN_EAGE; i > UP_EAGE; i--)
	{
		DiffSum += (RL[i] - LL[i]) - (MidOffset[i] << 1);
	}
	if (DiffSum > DiffTh)return 1;
	else return 0;
}
int Num_i = 0;
//================================================================//
//  @brief  :		�жϳ���·
//  @param  :		void
//  @return :		1�����ڶ�·  0�Ѿ����˶�·
//  @note   :		void
//================================================================//
int JudgeOutBroken(void)
{
	//return 3;
	//CannyEage();
	//VarInit();
	//LeftPnt.Type = RightPnt.Type = 0;
	//SelectFirstLine();
	//static int Num_i = 0;
	static int BrokenAve[5] = { 0 };
	if (BrokenFlag == 1)
	{
		if (Num_i < 5)
		{
			if (Num_i > 0 && BrokenAve[Num_i - 1] - LightThreshold > 30)
				return 1;
			BrokenAve[Num_i++] = LightThreshold;
			return 0;
		}
		else
		{
			for (int i = 0; i < 4; i++)		//��������Ԫ��
				BrokenAve[i] = BrokenAve[i + 1];
			BrokenAve[4] = LightThreshold;
			//�ж�����
			for (int i = 0; i < 4; i++)
			{
				for (int j = i; j < 5; j++)
				{
					if (BrokenAve[i] - BrokenAve[j] > 30)
						return 1;
				}
			}
			return 0;
		}

		//		if (BrokenLastAve == 0)
		//		{
		//			BrokenLastAve = LightThreshold;
		//			return 0;
		//		}
		//		else
		//		{
		//			if (BrokenLastAve - LightThreshold > 30)
		//			{
		//                          BrokenLastAve = LightThreshold;
		//				return 1;
		//			}
		//			else 
		//                        {
		//                          BrokenLastAve = LightThreshold;
		//                          return 0;
		//                        }
		//		}
	}
	else if(2 == BrokenFlag)
	{
		//FindLineNormal(0);
		if (LeftPnt.ErrRow < DOWN_EAGE - 20 && RightPnt.ErrRow < DOWN_EAGE - 20)
		{
			if (RL[DOWN_EAGE] - LL[DOWN_EAGE] > 94 && RL[DOWN_EAGE - 1] - LL[DOWN_EAGE - 1] > 94
				&& RL[DOWN_EAGE - 2] - LL[DOWN_EAGE - 2] > 94 && RL[DOWN_EAGE - 3] - LL[DOWN_EAGE - 3] > 94)
			{
				BrokenLastAve = 0;
				return 0;
			}
			else return 2;
		}
		else
		{
			return 2;
		}
	}
	return 0;
}

//================================================================//
//  @brief  :		ʶ��ͣ����
//  @param  :		void
//  @return :		1ͣ����  0��ͣ����
//  @note   :		void
//================================================================//
int IsStopLine(int line, int left, int right)
{
	int count = 0;
	for (int i = left + 1; i < right; )
	{
		i = SearchRightEage(line, i);
		i = SearchRightNoEage(line, i);
		count++;
		if (count > 6) return 1;
	}
	return 0;
}

//================================================================//
//  @brief  :		ʶ��ͣ�����Լ�����
//  @param  :		void
//  @return :		1ͣ����  0��ͣ����
//  @note   :		void
//================================================================//
int DistStopLine(int line)
{
	int a = IsStopLine(line, LL[line], RL[line]);
	line += 2;
	int b = IsStopLine(line, LL[line], RL[line]);
	line += 2;
	int c = IsStopLine(line, LL[line], RL[line]);
	if (a || b || c)return 1;
	else return 0;
}

//================================================================//
//  @brief  :		�жϽ����·V2
//  @param  :		void
//  @return :		void
//  @note   :		void
//================================================================//
int JudgeInBroken_V2(Point pa, Point pb)
{
	const int diff = 2;
	int NewRow = pa.Row;
	int NewRow2 = pb.Row;
	int OldRow = NewRow;
	int OldRow2 = NewRow2;
	int Middle = (pa.Col + pb.Col) >> 1;
	for (int i = pa.Col + 1; i <= Middle; i++)
	{
		NewRow = SearchUpEage(OldRow + 2, i);
		if (NewRow - OldRow > diff || OldRow - NewRow > diff)
			return 0;
		OldRow = NewRow;
	}
	for (int i = pb.Col - 1; i >= Middle; i--)
	{
		NewRow2 = SearchUpEage(OldRow2 + 2, i);
		if (NewRow2 - OldRow2 > diff || OldRow2 - NewRow2 > diff)
			return 0;
		OldRow2 = NewRow2;
	}
	if (NewRow == NewRow2)return 1;
	else return 0;
}

//================================================================//
//  @brief  :		�жϽ����·
//  @param  :		void
//  @return :		void
//  @note   :		void
//================================================================//
int JudgeInBroken(Point pa, Point pb)
{
	if (pb.Row - pa.Row < 10 && pa.Row - pb.Row < 10)
	{
		if (pa.Col < pb.Col)
			return IsConnectPoint(pa, pb);
		else return IsConnectPoint(pb, pa);
	}
	else return 0;
}

//================================================================//
//  @brief  :		�ж������Ƿ�����
//  @param  :		void
//  @return :		void
//  @note   :		void
//================================================================//
int IsConnectPoint(Point pa, Point pb)
{
	image[pa.Row][pa.Col] = 255;
	if (pa.Col == pb.Col && pa.Row == pb.Row) return 1;
	if (pa.Col < pb.Col)
	{
		if (ImageEage[pa.Row][pa.Col + 1] == HIGH_TH)
		{
			pa.Col++;
			return IsConnectPoint(pa, pb);
		}
		else if (pa.Row < pb.Row)
		{
			if (ImageEage[pa.Row + 1][pa.Col] == HIGH_TH)
			{
				pa.Row++;
				return IsConnectPoint(pa, pb);
			}
			else return 0;
		}
		else if (pa.Row > pb.Row)
		{
			if (ImageEage[pa.Row - 1][pa.Col] == HIGH_TH)
			{
				pa.Row--;
				return IsConnectPoint(pa, pb);
			}
			else return 0;
		}
		else return 0;
	}
	else if (pa.Row < pb.Row)
	{
		if (ImageEage[pa.Row + 1][pa.Col] == HIGH_TH)
		{
			pa.Row++;
			return IsConnectPoint(pa, pb);
		}
		else return 0;
	}
	else if (pa.Row > pb.Row)
	{
		if (ImageEage[pa.Row - 1][pa.Col] == HIGH_TH)
		{
			pa.Row--;
			return IsConnectPoint(pa, pb);
		}
		else return 0;
	}
	else return 0;
}

//================================================================//
//  @brief  :		�µ�·������
//  @param  :		void
//  @return :		1�µ� 2·��
//  @note   :		void
//================================================================//
int Diff_R_B(int state)
{
	if (state == 1)		//����־
	{
		if (LeftPnt.Type == 4 && RightPnt.Type == 4)
		{
			int left_eage = MaxArray(&LL[DOWN_EAGE], DOWN_EAGE - UP_EAGE);
			int right_eage = MinArray(&RL[DOWN_EAGE], DOWN_EAGE - UP_EAGE);
			int count = 0;
			for (int i = left_eage + 1; i < right_eage; i++)
			{
				if (UP_EAGE == SearchUpEage(DOWN_EAGE - 20, i))
					count++;
			}
			if (count > (right_eage - left_eage) * 0.8) return 1; //�µ�
			else return 2;//·��
		}
		else
		{
			return 2; //·��
		}
	}
}

//================================================================//
//  @brief  :		�����ٶȿ���
//  @param  :		middle ������ֵ
//  @return :		void
//  @note   :		void
//================================================================//
int GetSpeedRow(int middle, int left_row, int right_row)
{
	Point P[3] = {
		{DOWN_EAGE, middle - 5},
	{DOWN_EAGE, middle},
	{DOWN_EAGE, middle + 5} };
	int min_row = MIN(left_row, right_row);
	for (int i = DOWN_EAGE; i > UP_EAGE; i--)
	{
		if ((LL[i] - P[0].Col) * (LL[i - 1] - P[0].Col) <= 0
			|| (RL[i] - P[0].Col) * (RL[i - 1] - P[0].Col) <= 0
			|| UP_EAGE + 1 == i)
		{
			P[0].Row = MAX(i, min_row);
			break;
		}
	}
	for (int i = DOWN_EAGE; i > UP_EAGE; i--)
	{
		if ((LL[i] - P[1].Col) * (LL[i - 1] - P[1].Col) <= 0
			|| (RL[i] - P[1].Col) * (RL[i - 1] - P[1].Col) <= 0
			|| UP_EAGE + 1 == i)
		{
			P[1].Row = MAX(i, min_row);
			break;
		}
	}
	for (int i = DOWN_EAGE; i > UP_EAGE; i--)
	{
		if ((LL[i] - P[2].Col) * (LL[i - 1] - P[2].Col) <= 0
			|| (RL[i] - P[2].Col) * (RL[i - 1] - P[2].Col) <= 0
			|| UP_EAGE + 1 == i)
		{
			P[2].Row = MAX(i, min_row);
			break;
		}
	}
	return (P[1].Row + P[0].Row + P[2].Row) / 3;
}

//================================================================//
//  @brief  :		�����ٶȼ���
//  @param  :		row ������Ե����
//  @return :		void
//  @note   :		void
//================================================================//
int GetSpeedCount(int row, int speed_max, int speed_min, float a)
{
	if (50 < row) return speed_min;
	int temp = (int)(a * (50 - row) * (50 - row) + speed_min + 0.5f);
	return MIN(speed_max, temp);
}
