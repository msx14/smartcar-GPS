#ifndef BINARY_H_
#define BINARY_H_

void gray2Binary(unsigned char * srcImage, unsigned char * dstImage);
unsigned char otsuThreshold(unsigned char* image, int col, int row);

#endif