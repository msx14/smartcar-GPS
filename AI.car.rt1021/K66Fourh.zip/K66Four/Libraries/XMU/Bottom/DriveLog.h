#ifndef DRIVELOG_H_
#define DRIVELOG_H_
void LogInit(void);
void LogGetData(void);
void SaveInt(int data);
void SaveFloat(float data);
#endif //!DRIVELOG_H_