#ifndef __INIT_H__
#define __INIT_H__


#define SWITCH0_PIN PTB1
#define SWITCH1_PIN PTB0
#define SWITCH2_PIN PTA14
#define SWITCH3_PIN PTC10


void system_Init(void);









#endif

