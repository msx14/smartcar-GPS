#ifndef _ENCODER_H_
#define _ENCODER_H_



#define Encoder_FTM      ftm1

int Encoder_get(void);


#endif