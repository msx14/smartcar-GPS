#ifndef _DELAYDIST_H
#define _DELAYDIST_H
//void DistCI(void);
//void DistBroken(void);
//void IndCI(void);
//void ClearFlag(int* flag);
//void Angle_GoIslandSix(void);
#endif //!_DELAYDIST_H