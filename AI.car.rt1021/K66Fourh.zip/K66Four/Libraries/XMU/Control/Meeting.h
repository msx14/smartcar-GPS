#ifndef MEETING_H
#define MEETING_H
//void ChangeStartMeetingFlag(void);
//void MeetingCarControl(void);
//void ChangeEndMeetingFlag(void);
//void MeetingCtrlFun(void);
//void MeetingCtrlFun_1(void);
//void MeetingFour(void);
//void MeetingTwo(void);
//void SingleFour(void);

#endif //!MEETING_H