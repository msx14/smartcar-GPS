#ifndef MESSAGE_H
#define MESSAGE_H
void SendData(unsigned char Data);
void ReceiveData(void);

#endif //!MESSAGE_H