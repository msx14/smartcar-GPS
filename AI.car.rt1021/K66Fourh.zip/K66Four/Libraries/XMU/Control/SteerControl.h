#ifndef STEERCONTROL_H
#define STEERCONTROL_H

//void Ind_StopCar(void);
void CarControl(void);
void CarControl_Ind(void);
void SteerControl(void);
void ChangeSpeedFlag(unsigned char type);
void IndSteerControl(void);
void CameraSteerControl(void);
void RampJudge();

#endif