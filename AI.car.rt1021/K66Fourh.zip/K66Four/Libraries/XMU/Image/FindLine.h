#ifndef _FINDLINE_H_
#define _FINDLINE_H_

//�������߰汾4(����)
void FirstLineV4(void);
int FirstRowProcess(void);
void FindLineNormal(int Fill);
void FindLineLost(void);
Point FindLowPoint(int row, int col1, int col2, int Step);






#endif