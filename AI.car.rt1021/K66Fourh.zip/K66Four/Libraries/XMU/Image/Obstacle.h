#ifndef __OBSTACLE_H__
#define __OBSTACLE_H__

void JudgeRamp(void);
void roadblock3(void);
int JudgeMaxAngle(float real_angle, float obj_angle);
float AngleError(float real_angle, float obj_angle);
void inf();

#endif