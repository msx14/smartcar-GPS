#ifndef OTSU_H
#define OTSU_H
#include "common.h"
//unsigned char otsuThreshold2(uint8 *image, uint16 col, uint16 row,uint8 sparse);

#endif