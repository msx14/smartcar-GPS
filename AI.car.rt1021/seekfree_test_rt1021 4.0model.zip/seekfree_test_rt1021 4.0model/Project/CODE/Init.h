#ifndef __INIT_H__
#define __INIT_H__

 void system_init();

  #endif 