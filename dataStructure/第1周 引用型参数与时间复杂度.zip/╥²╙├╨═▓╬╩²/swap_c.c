void swap_c(int x, int y)
{
    int tmp;
    tmp=x; x=y; y=tmp;
}

main()
{   int a, b;
    a=2;b=3;
    swap_c(a,b);
    printf("a=%d    b=%d\n",a,b);

}
